/*
 *	wiiuse
 *
 *	Written By:
 *		Michael Laforest	< para >
 *		Email: < thepara (--AT--) g m a i l [--DOT--] com >
 *
 *	Copyright 2006-2007
 *
 *	This file is part of wiiuse.
 *
 *	This program is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *	$Header$
 *
 */

/**
 *	@file
 *	@brief Nunchuk expansion device.
 */

#ifndef NUNCHUK_H_INCLUDED
#define NUNCHUK_H_INCLUDED

#include "wiiuse_internal.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup internal_nunchuk Internal: Nunchuk */
/** @{ */
int nunchuk_handshake(struct wiimote_t *wm, struct nunchuk_t *nc, byte *data, unsigned short len);

void nunchuk_disconnected(struct nunchuk_t *nc);

void nunchuk_event(struct nunchuk_t *nc, byte *msg);

void nunchuk_pressed_buttons(struct nunchuk_t *nc, byte now);
/** @} */

#ifdef __cplusplus
}
#endif

#endif /* NUNCHUK_H_INCLUDED */
